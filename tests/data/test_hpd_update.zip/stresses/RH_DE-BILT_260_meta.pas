{
    "x": 140565.1525057242,
    "y": 456790.9991188961,
    "location": "",
    "filename": "",
    "source": "KNMI",
    "unit": "mm",
    "station": 260,
    "meteo_var": "RH",
    "kind": "prec"
}