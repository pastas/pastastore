{
    "x": 118064.19606548503,
    "y": 439799.96794952714,
    "location": "GMW000000036327",
    "filename": "",
    "source": "BRO",
    "unit": "m NAP",
    "tube_nr": 1,
    "screen_top": -0.833,
    "screen_bottom": -1.833,
    "ground_level": 0.856,
    "tube_top": 0.716,
    "metadata_available": true
}