{
    "x": 117957.01006548283,
    "y": 439698.23594952864,
    "location": "GMW000000036319",
    "filename": "",
    "source": "BRO",
    "unit": "m NAP",
    "tube_nr": 1,
    "screen_top": -1.721,
    "screen_bottom": -2.721,
    "ground_level": -0.501,
    "tube_top": -0.621,
    "metadata_available": true
}