{
    "x": 118127.47006548365,
    "y": 439683.13594953006,
    "location": "GMW000000036365",
    "filename": "",
    "source": "BRO",
    "unit": "m NAP",
    "tube_nr": 1,
    "screen_top": -0.429,
    "screen_bottom": -1.428,
    "ground_level": 1.371,
    "tube_top": 1.221,
    "metadata_available": true
}